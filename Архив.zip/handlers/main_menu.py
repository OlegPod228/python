import random

import aiogram
from aiogram import types, Dispatcher
from aiogram.utils.exceptions import ChatNotFound, BotBlocked

import config
import data_base_api
from create_bot import bot
from keyboards import admin_keyboards, users_keyboards


async def get_materials_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        old_stats_data = data_base_api.get_stats_data()
        data_base_api.update_stats(setup_id=old_stats_data['setup_id'],
                                   media_getted=old_stats_data['media_getted'] + 1)
        user_data = data_base_api.get_user(telegram_id=message.from_user.id)
        if not user_data['is_banned']:
            if len([posts for posts in data_base_api.get_all_posts() if posts['moderated_by'] != None]) >= 1:
                random_material_from_data_base = random.choice([posts for posts in data_base_api.get_all_posts() if posts['moderated_by'] != None])
                if random_material_from_data_base['type'] == 'photo':
                    await bot.send_photo(chat_id=message.from_user.id,
                                         photo=random_material_from_data_base['post_file_id'], caption=data_base_api.get_post_messages_data(random_material_from_data_base['post_id']),
                                             reply_markup=admin_keyboards.content_check(user_id=message.from_user.id,
                                                                                        post_id=random_material_from_data_base['post_id']))
                if random_material_from_data_base['type'] == 'video':
                    await bot.send_video(chat_id=message.from_user.id,
                                         video=random_material_from_data_base['post_file_id'], caption=data_base_api.get_post_messages_data(random_material_from_data_base['post_id']),
                                             reply_markup=admin_keyboards.content_check(user_id=message.from_user.id,
                                                                                        post_id=random_material_from_data_base['post_id']))
                if random_material_from_data_base['type'] == 'voice':
                    await bot.send_voice(chat_id=message.from_user.id,
                                         voice=random_material_from_data_base['post_file_id'], caption=data_base_api.get_post_messages_data(random_material_from_data_base['post_id']),
                                             reply_markup=admin_keyboards.content_check(user_id=message.from_user.id,
                                                                                        post_id=random_material_from_data_base['post_id']))
                if random_material_from_data_base['type'] == 'gif':
                    await bot.send_animation(chat_id=message.from_user.id,
                                             animation=random_material_from_data_base['post_file_id'], caption=data_base_api.get_post_messages_data(random_material_from_data_base['post_id']),
                                             reply_markup=admin_keyboards.content_check(user_id=message.from_user.id,
                                                                                        post_id=random_material_from_data_base['post_id']))
            else:
                await bot.send_message(chat_id=message.from_user.id,
                                       text='Порожньо')


async def get_contacts_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        old_stats_data = data_base_api.get_stats_data()
        data_base_api.update_stats(setup_id=old_stats_data['setup_id'],
                                   contacts_getted=old_stats_data['contacts_getted'] + 1)
        if not user_data['is_banned']:
            contacts_list = [contact for contact in data_base_api.get_all_contacts() if contact['moderated_by'] is not None]

            if len(contacts_list) > 1:
                random_contact_from_data_base = sorted(contacts_list, key=lambda x: x['sended_count'], reverse=False)
                contact_data = data_base_api.get_contact(contact_id=random_contact_from_data_base[0]['contact_id'])
                data_base_api.update_contact(contact_id=contact_data['contact_id'],
                                          sended_count=contact_data['sended_count'] + 1)

                contact_to_send = random_contact_from_data_base[0]['contact']
            elif len(contacts_list) == 1:
                contact_data = data_base_api.get_contact(contact_id=contacts_list[0]['contact_id'])
                data_base_api.update_contact(contact_id=contact_data['contact_id'],
                                          sended_count=contact_data['sended_count'] + 1)
                contact_to_send = contacts_list[0]['contact']
            else:
                contact_to_send = 'None'
            try:
                if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                    await bot.send_message(chat_id=message.from_user.id,
                                           text=contact_to_send, reply_markup=admin_keyboards.contact_check(user_id=0,
                                                                                                            contact_id=contact_data['contact_id']))
                else:
                    await bot.send_message(chat_id=message.from_user.id,
                                           text=contact_to_send, reply_markup=users_keyboards.report_keyboard(contact_id=contact_data['contact_id']))
            except UnboundLocalError:
                await bot.send_message(chat_id=message.from_user.id,
                                       text='Порожньо')


async def get_bots_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
       await bot.send_message(chat_id=message.from_user.id,
                             text=config.bot_texts['ask_for_bot_message_text'])


async def vsu_donate_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        await bot.send_message(chat_id=message.from_user.id,
                               text=config.bot_texts['vsu_donate_url'])


async def get_moderator_rights_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:

        if not user_data['ask_to_be_moderator']:
            data_base_api.update_user(telegram_id=message.from_user.id,
                                      ask_to_be_moderator=1)
            for admins in config.admins_ids:
                try:
                    await bot.send_message(chat_id=admins, text='Було зареєстровано заявку на пост модератора.\n\n'
                                                                f'{message.from_user}',
                                           reply_markup=admin_keyboards.add_moderator_keyboard(message.from_user.id))
                except (BotBlocked, ChatNotFound):
                    pass
            await bot.send_message(chat_id=message.from_user.id,
                                   text="Ви успішно залишили заявку на те, щоб бути модератором, ви отримаєте відповідь найближчим часом",
                                   reply_markup=users_keyboards.base_keyboard(message.from_user.
                                                                              id))



async def send_bot_to_friend_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        bot_data = await bot.get_me()
        await bot.send_message(chat_id=message.from_user.id,
                               text=f"{config.bot_texts['bot_partner_message']}\n\n"
                                    f"@{bot_data.username}")


async def stats_button_callback(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        all_users_list = data_base_api.get_all_users()
        stats = data_base_api.get_stats_data()
        media_list = data_base_api.get_all_posts()
        contacts_list = data_base_api.get_all_contacts()
        stats_text = f"Всього людей в боті: {len(all_users_list)}\n" \
                     f"Медіа файлів у базі: {len(media_list)}\n" \
                     f"Контактів у базі: {len(contacts_list)}\n" \
                     f"Всього роздано медіа: {stats['media_getted']}\n" \
                     f"Всього роздано контактів: {stats['contacts_getted']}"
        await bot.send_message(chat_id=message.from_user.id,
                               text=stats_text)


def  main_menu_handlers(dp: Dispatcher):

    dp.register_message_handler(stats_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['stats_button_name']))
    dp.register_message_handler(send_bot_to_friend_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['send_bot_to_friend_button_name']))
    dp.register_message_handler(get_materials_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['get_materials_button_name']))
    dp.register_message_handler(get_contacts_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['get_contacts_button_name']))
    dp.register_message_handler(get_bots_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['get_bots_button_name']))
    dp.register_message_handler(vsu_donate_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['vsu_donate_button_name']))
    dp.register_message_handler(get_moderator_rights_button_callback,
                                aiogram.dispatcher.filters.Text(
                                    equals=config.buttons_names['get_moderator_rights_button_name']))