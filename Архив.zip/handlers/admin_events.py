import ast
import time

from aiogram import types, Dispatcher
from aiogram.utils.exceptions import MessageToDeleteNotFound

import config
import data_base_api
from create_bot import bot
from keyboards import admin_keyboards, users_keyboards


async def approve_post_callback(callback_query: types.CallbackQuery):
    current_post_id = callback_query.data.split('~')[1]
    message_data = data_base_api.get_post_messages_data(post_id=current_post_id)
    if message_data is not None:
        for data in ast.literal_eval(message_data['message_data']):
            try:
                await bot.delete_message(chat_id=data[0], message_id=data[1])
            except MessageToDeleteNotFound:
                pass
    data_base_api.update_post(post_id=current_post_id, moderated_by=callback_query.from_user.id)
    post_data = data_base_api.get_post(post_id=current_post_id)
    await bot.send_message(chat_id=post_data['sended_by'], text=config.bot_texts['content_added_text'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def ban_user_callback(callback_query: types.CallbackQuery):

    data_base_api.update_user(telegram_id=callback_query.data.split('~')[1], is_banned=1)
    await bot.send_message(chat_id=callback_query.from_user.id, text=config.bot_texts['user_success_banned'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def add_contacts_callback(callback_query: types.CallbackQuery):
    message_data = data_base_api.get_contact_messages_data(contact_id=callback_query.data.split(('~'))[1])
    if message_data is not None:
        for data in ast.literal_eval(message_data['message_data']):
            try:
                await bot.delete_message(chat_id=data[0], message_id=data[1])
            except MessageToDeleteNotFound:
                pass
    contacts_data = data_base_api.get_contact(contact_id=callback_query.data.split(('~'))[1])
    if contacts_data is not None:
        data_base_api.delete_contact(contact_id=contacts_data['contact_id'])
        for data in ast.literal_eval(contacts_data['contact']):
            data_base_api.add_contact(sended_by=contacts_data['sended_by'],
                                      sended_count=0,
                                      moderated_by=callback_query.from_user.id,
                                      contact=data,
                                      unix_content_creation_date=round(time.time()),
                                      )
    else:
        await bot.delete_message(chat_id=callback_query.message.chat.id,
                                 message_id=callback_query.message.message_id)
    await bot.send_message(chat_id=contacts_data['sended_by'], text=config.bot_texts['contact_added_text'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def contact_report_callback(callback_query: types.CallbackQuery):
    await bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)
    contact_id = callback_query.data.split('~')[1]
    contact_data = data_base_api.get_contact(contact_id=contact_id)
    await bot.send_message(chat_id=callback_query.from_user.id, text=config.bot_texts['report_sended_seccess_text'])
    users_list = config.admins_ids
    users_list.extend(
        [moderators["telegram_id"] for moderators in data_base_api.get_all_users() if moderators['is_moderator'] == 1])
    all_post_messages_data = []
    for admins in set(users_list):
        print(admins)
        message_data = await bot.send_message(chat_id=admins, text=f"{config.bot_texts['invalide_contact_message_to_admin_text']}\n\n{contact_data['contact']}",
                               reply_markup=admin_keyboards.contact_check(user_id=0, contact_id=contact_id))
        all_post_messages_data.append([message_data.chat.id, message_data.message_id])
        data_base_api.add_delete_contact_messages_data(contact_id, message_data=str(all_post_messages_data))
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def add_moder_callback(callback_query: types.CallbackQuery):
    data_base_api.update_user(telegram_id=callback_query.data.split('~')[1], is_moderator=1)
    await bot.send_message(chat_id=callback_query.data.split('~')[1], text=config.bot_texts['message_to_candidat_when_get_moder'],
                           reply_markup=users_keyboards.base_keyboard(callback_query.from_user.id))
    await bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def delete_post_callback(callback_query: types.CallbackQuery):
    data_base_api.delete_post(post_id=int(callback_query.data.split('~')[2]))
    await bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)
    await bot.send_message(chat_id=callback_query.from_user.id, text=config.bot_texts['record_success_deleted'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def delete_contact_callback(callback_query: types.CallbackQuery):
    message_data = data_base_api.get__delete_contact_messages_data(contact_id=int(callback_query.data.split('~')[2]))
    if message_data is not None:
        for data in ast.literal_eval(message_data['message_data']):
            try:
                await bot.delete_message(chat_id=data[0], message_id=data[1])
            except MessageToDeleteNotFound:
                pass
    data_base_api.delete_contact(contact_id=int(callback_query.data.split('~')[2]))
    try:
        await bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)
    except MessageToDeleteNotFound:
        pass
    await bot.send_message(chat_id=callback_query.from_user.id, text=config.bot_texts['record_success_deleted'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


async def sended_contact_callback(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id)
    except MessageToDeleteNotFound:
        pass
    data_base_api.add_sended_post()
    await bot.send_message(chat_id=callback_query.from_user.id, text=config.bot_texts['thanks_for_sending_text'])
    await bot.answer_callback_query(callback_query_id=callback_query.id)


def register_admin_events_handlers(dp: Dispatcher):
    dp.register_callback_query_handler(sended_contact_callback, lambda c: c.data and c.data.startswith('sended'))
    dp.register_callback_query_handler(approve_post_callback, lambda c: c.data and c.data.startswith('approve~'))
    dp.register_callback_query_handler(ban_user_callback, lambda c: c.data and c.data.startswith('ban~'))
    dp.register_callback_query_handler(add_contacts_callback, lambda c: c.data and c.data.startswith('contacts~'))
    dp.register_callback_query_handler(delete_post_callback, lambda c: c.data and c.data.startswith('d~post~'))
    dp.register_callback_query_handler(contact_report_callback, lambda c: c.data and c.data.startswith('report~'))
    dp.register_callback_query_handler(add_moder_callback, lambda c: c.data and c.data.startswith('add_moder~'))
    dp.register_callback_query_handler(delete_contact_callback, lambda c: c.data and c.data.startswith('d~contact'))

