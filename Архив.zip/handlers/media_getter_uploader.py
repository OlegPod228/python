import time

from aiogram import types, Dispatcher
from aiogram.utils.exceptions import BotBlocked, ChatNotFound

import config
import data_base_api
from create_bot import bot
from keyboards import admin_keyboards


# @dp.message_handler(state=AnswerToFeedbackForm.answer_text, content_types=types.ContentTypes.ANY)
async def media_or_contact_getter(message: types.Message):
    user_data = data_base_api.get_user(telegram_id=message.from_user.id)
    if not user_data['is_banned']:
        if message.photo:
            if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                moderated_by = message.from_user.id
                text_to_send = config.bot_texts['moderaor_add_something_text']
                post_id = data_base_api.add_post(sended_by=message.from_user.id,
                                       moderated_by=moderated_by,
                                       post_file_id=message.photo[-1]['file_id'],
                                       unix_content_creation_date=round(time.time()),
                                       type='photo')
                if (message.caption is not None):
                    data_base_api.add_post_messages_data(post_id, message_data=message.caption)
                else:
                    data_base_api.add_post_messages_data(post_id, message_data="")
            # else:
            #     moderated_by = None
            #     text_to_send = config.bot_texts['content_added_to_review_text']
            # post_id = data_base_api.add_post(sended_by=message.from_user.id,
            #                                  moderated_by=moderated_by,
            #                                  post_file_id=message.photo[-1]['file_id'],
            #                                  unix_content_creation_date=round(time.time()),
            #                                  type='photo')[1]
            # if moderated_by is None:
            #     users_list = config.admins_ids
            #     moderators_ids = [moderators["telegram_id"] for moderators in data_base_api.get_all_users() if moderators['is_moderator'] == 1]
            #     users_list.extend(moderators_ids)
            #     all_post_messages_data = []
            #     for users in set(users_list):
            #         try:
            #             message_data = await bot.send_photo(chat_id=users,
            #                                      photo=message.photo[-1]['file_id'],
            #                                      reply_markup=admin_keyboards.approve_moderator_keyboard(post_id=post_id))
            #             all_post_messages_data.append([users, message_data.message_id])
            #         except (BotBlocked, ChatNotFound):
            #             pass
            #     data_base_api.add_post_messages_data(post_id, message_data=str(all_post_messages_data))
            await bot.send_message(chat_id=message.from_user.id,
                                   text=text_to_send)
        if message.video:
            if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                moderated_by = message.from_user.id
                text_to_send = config.bot_texts['moderaor_add_something_text']
                post_id = data_base_api.add_post(sended_by=message.from_user.id,
                                                 moderated_by=moderated_by,
                                                 post_file_id=message.video['file_id'],
                                                 unix_content_creation_date=round(time.time()),
                                                 type='video')
                if (message.caption is not None):
                    data_base_api.add_post_messages_data(post_id, message_data=message.caption)
                else:
                    data_base_api.add_post_messages_data(post_id, message_data="")

            # if moderated_by is None:
            #     users_list = config.admins_ids
            #     users_list.extend([moderators["telegram_id"] for moderators in data_base_api.get_all_users() if moderators['is_moderator'] == 1])
            #     all_post_messages_data = []
            #     for users in users_list:
            #         try:
            #             message_data = await bot.send_video(chat_id=users,
            #                                  video=message.video['file_id'],
            #                                  reply_markup=admin_keyboards.approve_moderator_keyboard(post_id=post_id))
            #             all_post_messages_data.append([users, message_data.message_id])
            #         except (BotBlocked, ChatNotFound):
            #             pass
            #     data_base_api.add_post_messages_data(post_id, message_data=str(all_post_messages_data))
            await bot.send_message(chat_id=message.from_user.id,
                                   text=text_to_send)

        if message.voice:
            if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                moderated_by = message.from_user.id
                text_to_send = config.bot_texts['moderaor_add_something_text']
                data_base_api.add_post(sended_by=message.from_user.id,
                                       moderated_by=moderated_by,
                                       post_file_id=message.voice['file_id'],
                                       unix_content_creation_date=round(time.time()),
                                       type='voice')
                if (message.caption is not None):
                    data_base_api.add_post_messages_data(post_id, message_data=message.caption)
                else:
                    data_base_api.add_post_messages_data(post_id, message_data="")
            # else:
            #     moderated_by = None
            #     text_to_send = config.bot_texts['content_added_to_review_text']
            # post_id = [1]
            # if moderated_by is None:
            #     users_list = config.admins_ids
            #     users_list.extend([moderators["telegram_id"] for moderators in data_base_api.get_all_users() if moderators['is_moderator'] == 1])
            #     all_post_messages_data = []
            #     for users in users_list:
            #         try:
            #             message_data = await bot.send_voice(chat_id=users,
            #                                  voice=message.voice['file_id'],
            #                                  reply_markup=admin_keyboards.approve_moderator_keyboard(post_id=post_id))
            #             all_post_messages_data.append([users, message_data.message_id])
            #         except (BotBlocked, ChatNotFound):
            #             pass
            #     data_base_api.add_post_messages_data(post_id, message_data=str(all_post_messages_data))
                await bot.send_message(chat_id=message.from_user.id,
                                       text=text_to_send)
        if message.animation:
            if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                moderated_by = message.from_user.id
                text_to_send = config.bot_texts['moderaor_add_something_text']
                data_base_api.add_post(sended_by=message.from_user.id,
                                       moderated_by=moderated_by,
                                       post_file_id=message.animation['file_id'],
                                       unix_content_creation_date=round(time.time()),
                                       type='gif')
                if (message.caption is not None):
                    data_base_api.add_post_messages_data(post_id, message_data=message.caption)
                else:
                    data_base_api.add_post_messages_data(post_id, message_data="")
            # else:
            #     moderated_by = None
            #     text_to_send = config.bot_texts['content_added_to_review_text']
            # post_id = data_base_api.add_post(sended_by=message.from_user.id,
            #                                  moderated_by=moderated_by,
            #                                  post_file_id=message.animation['file_id'],
            #                                  unix_content_creation_date=round(time.time()),
            #                                  type='gif')[1]
            # if moderated_by is None:
            #     users_list = config.admins_ids
            #     users_list.extend([moderators["telegram_id"] for moderators in data_base_api.get_all_users() if moderators['is_moderator'] == 1])
            #     all_post_messages_data = []
            #     for users in users_list:
            #         try:
            #             message_data = await bot.send_animation(chat_id=users,
            #                                  animation=message.animation['file_id'],
            #                                  reply_markup=admin_keyboards.approve_moderator_keyboard(post_id=post_id))
            #             all_post_messages_data.append([users, message_data.message_id])
            #         except (BotBlocked, ChatNotFound):
            #             pass
            #     data_base_api.add_post_messages_data(post_id, message_data=str(all_post_messages_data))
            await bot.send_message(chat_id=message.from_user.id,
                                   text=text_to_send)
        if message.text:
            if message.from_user.id in config.admins_ids or user_data['is_moderator']:
                for contacts in message.text.split('\n'):
                    print('da')
                    data_base_api.add_contact(sended_by=message.from_user.id,
                                                           moderated_by=message.from_user.id,
                                                           contact=contacts,
                                                           unix_content_creation_date=round(time.time()),
                                                           sended_count=0)
                    text_to_send = config.bot_texts['moderaor_add_something_text']
            # else:
            #     text_to_send = config.bot_texts['contact_added_to_review_text']
            #     users_list = config.admins_ids
            #     users_list.extend([moderators["telegram_id"] for moderators in data_base_api.get_all_users() if
            #                        moderators['is_moderator'] == 1])
            #     all_post_messages_data = []
            #     contact_id = data_base_api.add_contact(sended_by=message.from_user.id,
            #                               moderated_by=None,
            #                               contact=str(message.text.split('\n')),
            #                               unix_content_creation_date=round(time.time()),
            #                               sended_count=0)[1]
                # for users in users_list:
                #     try:
                #         message_data = await bot.send_message(chat_id=users,
                #                                             text=str(message.text.split('\n')),
                #                                             reply_markup=admin_keyboards.contact_moderator_keyboard(
                #                                             contact_id=contact_id))
                #         all_post_messages_data.append([users, message_data.message_id])
                #     except (BotBlocked, ChatNotFound):
                #         pass
                # data_base_api.add_contact_messages_data(contact_id, message_data=str(all_post_messages_data))
                list_len = len(message.text.split('\n'))
                await bot.send_message(chat_id=message.from_user.id,
                                       text=f"{text_to_send}\n\n"
                                            f"добавлено {list_len}")


def register_media_handlers(dp: Dispatcher):
    dp.register_message_handler(media_or_contact_getter, content_types=types.ContentTypes.ANY)
