import time
from datetime import datetime

import aiogram
from aiogram import types
from aiogram.types import ChatType, ParseMode
from aiogram.utils import executor

import config
import data_base_api
from create_bot import bot, dp
from handlers import main_menu, admin_events, media_getter_uploader
from keyboards import users_keyboards


@dp.message_handler(aiogram.filters.ChatTypeFilter(chat_type=ChatType.PRIVATE), commands=['start'])
async def process_start_command(message: types.Message):


    data_base_api.add_user(telegram_id=message.from_user.id,
                           full_name=message.from_user.full_name,
                           telegram_username=message.from_user.username,
                           ask_to_be_moderator=0,
                           is_moderator=0,
                           unix_registration_date=round(time.time()),
                           registration_date=datetime.now(),
                           is_banned=0)
    await bot.send_message(chat_id=message.from_user.id, text=config.bot_texts['bot_start_text'],
                           reply_markup=users_keyboards.base_keyboard(user_id=message.from_user.id),
                           parse_mode=ParseMode.HTML)


if __name__ == '__main__':
    main_menu.main_menu_handlers(dp)
    admin_events.register_admin_events_handlers(dp)
    media_getter_uploader.register_media_handlers(dp)
    executor.start_polling(dp)