import os


admins_ids = [999678965, 478200119, 779917069]

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bot_token = '5222967191:AAEhbby5RckNgbHgtcZnxhKul_NeW6jE2Lg'
bot_path_name = 'ukraine_bot'
path_to_db = os.path.join(BASE_DIR, bot_path_name, 'ukraine_bot_data_base.sqlite')


buttons_names = {
    "get_materials_button_name": "Отримати матеріали",
    "get_contacts_button_name": "Отримати контакти",
    "get_bots_button_name": "Замовити бота",
    "send_bot_to_friend_button_name": "Подiлитися ботом",
    "vsu_donate_button_name": "Допомога армії",
    'stats_button_name': 'Cтатистика',
    "get_moderator_rights_button_name": "Стати модератором",


    "approve_moderator_button": "Опублiкувати",
    "ban_user_button_name": "Заблокувати",
    "ban_mod_button_name": "Заблокувати модератора",
    'delete_post_button_name': "Видалити",

    "approve_moderator_button_name": "Призначити",

    'contact_invlaid_report_button_name': "Не знайшов в месенджерах",
    'contact_message_sended_button_name': 'Відправив',
    'one_more_contact_button_name': 'Ще один номер'


}

bot_texts = {
    "bot_start_text": 'Як ви можете деморалізувати ворога?\n\n1. Натисніть кнопку "Отримати контакт"\n2. Скопіюйте номер окупанта і знайдіть його в месенджерах (Viber, Telegram, WhatsApp). \n3. Натисніть кнопку "Отримати матеріал"\n4. Скопіюйте текст, завантажте відео або фото. \n5. Перейдіть в месенджер, в якому ви знайшли окупанта і відправте весь цей матеріал йому. \n\nДля того, щоб поділитися матеріалом, або додати контакти військових рашки-парашки, надішліть їх для модератора @ochki_okupanta',

    "moderaor_add_something_text": "Iнформацiю було додано",
    "content_added_to_review_text": "Спасибі за матеріали, вони будуть додані до спільного архіву після перевірки",
    "content_added_text": "Матеріали, які ви надіслали, були додані до нашого архіву. Дякуємо, що допомагаєте розповсюджувати інформацію!",

    "contact_added_to_review_text": "Контакти які ви надіслали будуть оброблені нашими модераторами та додані, спасибі за співпрацю!",
    'contact_added_text': "Контакти, які ви надіслали, були успішно додані в загальну базу!",

   "user_success_banned": "Користувач був заблокований",
   'record_success_deleted': "Дані були успішно видалені з бази",
    'report_sended_seccess_text': 'Скаргу було надіслано ми розглянемо її найближчим часом',

    'ask_for_bot_message_text': "Я розробив цього бота за дуже маленькі гроші, сподіваючись допомогти українцю перемогти! Якщо раптом вам потрібний програміст - будь ласка, найміть мене. Роботи зараз вісім мало.\n\nhttps://freelancehunt.com/freelancer/prudnikov21.html",

    'vsu_donate_url': "https://biz.ligazakon.net/news/209669_dopomoga-arm-ukrani-kudi-mozhna-pererakhuvati-koshti",

    "bot_partner_message": "Просто надішліть це повідомлення знайомим.У цьому телеграм боті ти зможеш відкрити солдатам РФ та жителям РФ очі на те, що відбувається в Україні. Російська війна теж важлива! Підтримай країну!",

    'invalide_contact_message_to_admin_text' : 'Один з користувачів робота повідомляє що контакт вже не працює. Ви можете видалити цей контакт або заблокувати користувача.',

    'message_to_candidat_when_get_moder': "Ви були призначені модератором!",

    'thanks_for_sending_text': '"Чудово! Ми стали на крок ближче до перемоги!!! Отримаєте ще один контакт?"'
}