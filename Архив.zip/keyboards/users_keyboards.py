from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import data_base_api
import config


def base_keyboard(user_id):
    user_data = data_base_api.get_user(telegram_id=user_id)
    base_keyboard_markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    get_materials_button = KeyboardButton(text=config.buttons_names['get_materials_button_name'])
    get_contacts_button = KeyboardButton(text=config.buttons_names['get_contacts_button_name'])
    stats_button = KeyboardButton(text=config.buttons_names['stats_button_name'])
    send_bot_to_friend_button_name = KeyboardButton(text=config.buttons_names['send_bot_to_friend_button_name'])
    vsu_donate_button = KeyboardButton(text=config.buttons_names['vsu_donate_button_name'])
    get_moderator_rights_button = KeyboardButton(text=config.buttons_names['get_moderator_rights_button_name'])
    base_keyboard_markup.insert(get_materials_button)
    base_keyboard_markup.insert(get_contacts_button)
    base_keyboard_markup.insert(vsu_donate_button)
    base_keyboard_markup.insert(send_bot_to_friend_button_name)
    base_keyboard_markup.insert(stats_button)
    if not user_data['ask_to_be_moderator']:
        base_keyboard_markup.insert(get_moderator_rights_button)
    return base_keyboard_markup


def report_keyboard(contact_id):
    report_keyboard_markup = InlineKeyboardMarkup()
    report_button = InlineKeyboardButton(text=config.buttons_names['contact_invlaid_report_button_name'],
                                         callback_data=f"report~{contact_id}")
    contact_message_sended_button = InlineKeyboardButton(
        text=config.buttons_names['contact_message_sended_button_name'], callback_data=f"sended")
    report_keyboard_markup.add(contact_message_sended_button)
    report_keyboard_markup.add(report_button)
    return report_keyboard_markup
