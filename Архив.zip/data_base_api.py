# - *- coding: utf- 8 - *-
import ast
import sqlite3
from sqlite3 import IntegrityError

import config


# Путь к БД

def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


####################################################################################################
###################################### ФОРМАТИРОВАНИЕ ЗАПРОСА ######################################
# Форматирование запроса с аргументами
def update_format_with_args(sql, parameters: dict):
    values = ", ".join([
        f"{item} = ?" for item in parameters
    ])
    sql = sql.replace("XXX", values)
    return sql, tuple(parameters.values())


# Форматирование запроса без аргументов
def get_format_args(sql, parameters: dict):
    sql += " AND ".join([
        f"{item} = ?" for item in parameters
    ])
    return sql, tuple(parameters.values())


def get_user_done_tasks(telegram_id):
    string_data = get_user(telegram_id=telegram_id)['tasks_completed_dict']
    if string_data == 'empty':
        return dict()
    else:
        return ast.literal_eval(string_data)


def add_user(telegram_id, full_name, telegram_username, registration_date, is_moderator,
             unix_registration_date, ask_to_be_moderator, is_banned):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            db.execute("INSERT INTO admin_panel_users "
                       "(telegram_id, full_name, telegram_username, registration_date, unix_registration_date, is_moderator, ask_to_be_moderator, is_banned) "
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                       [telegram_id, full_name, telegram_username, registration_date,
                        unix_registration_date, is_moderator, ask_to_be_moderator, is_banned])
            db.commit()
            return True
    except IntegrityError:
        return False


def get_all_users():
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        cur.execute("SELECT * FROM admin_panel_users ")
        return cur.fetchall()


def get_user(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM admin_panel_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchone()


def update_user(telegram_id, **kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = f"UPDATE admin_panel_users SET XXX WHERE telegram_id = {telegram_id}"
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()


def delete_user(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = "DELETE FROM admin_panel_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()


def get_users(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM admin_panel_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchall()




def add_post(sended_by, moderated_by, post_file_id, unix_content_creation_date, type):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO posts_data "
                       "(sended_by, moderated_by, post_file_id, unix_content_creation_date, type) "
                       "VALUES (?, ?, ?, ?, ?)",
                       [sended_by, moderated_by, post_file_id, unix_content_creation_date, type])
            post_id = cursor.lastrowid
            assert post_id is not None
            db.commit()
            return [True, post_id]
    except IntegrityError:
        return False


def update_post(post_id, **kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = f"UPDATE posts_data SET XXX WHERE post_id = {post_id}"
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()

def get_all_posts():
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        cur.execute("SELECT * FROM posts_data ")
        return cur.fetchall()


def get_post(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM posts_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchone()


def delete_post(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = "DELETE FROM posts_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()


def get_posts(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM posts_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchall()


def add_contact(sended_by, moderated_by, contact, unix_content_creation_date, sended_count):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO contacts_data "
                       "(sended_by, moderated_by, contact, unix_content_creation_date, sended_count) "
                       "VALUES (?, ?, ?, ?, ?)",
                       [sended_by, moderated_by, contact, unix_content_creation_date, sended_count])
            post_id = cursor.lastrowid
            assert post_id is not None
            db.commit()
            return [True, post_id]
    except IntegrityError:
        return False


def get_all_contacts():
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        cur.execute("SELECT * FROM contacts_data ")
        return cur.fetchall()


def delete_contact(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = "DELETE FROM contacts_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()


def get_contact(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM contacts_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchone()

def update_contact(contact_id, **kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = f"UPDATE contacts_data SET XXX WHERE contact_id = {contact_id}"
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()

def add_post_messages_data(post_id, message_data):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO message_data (post_id, message_data) VALUES (?,?)", [post_id[-1], message_data])
            post_id = cursor.lastrowid
            assert post_id is not None
            db.commit()
            return [True, post_id]
    except IntegrityError:
        return False


def get_post_messages_data(post_id):
    with sqlite3.connect(config.path_to_db) as db:
        try:
            cursor = db.cursor()
            return cursor.execute("SELECT message_data FROM message_data WHERE post_id = ?", (post_id,)).fetchone()[0]
        except Exception as e:
            print(e)
            return ""

def add_contact_messages_data(contact_id, message_data):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO contacts_message_data "
                       "(contact_id, message_data) "
                       "VALUES (?, ?)",
                       [contact_id, message_data])
            contact_id = cursor.lastrowid
            assert contact_id is not None
            db.commit()
            return [True, contact_id]
    except IntegrityError:
        return False


def get_contact_messages_data(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM contacts_message_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchone()

def add_delete_contact_messages_data(contact_id, message_data):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO delete_contacts_message_data "
                       "(contact_id, message_data) "
                       "VALUES (?, ?)",
                       [contact_id, message_data])
            contact_id = cursor.lastrowid
            assert contact_id is not None
            db.commit()
            return [True, contact_id]
    except IntegrityError:
        return False


def get__delete_contact_messages_data(**kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM delete_contacts_message_data WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        return cur.execute(sql, parameters).fetchone()

def add_stats(contacts_getted, media_getted):
    try:
        with sqlite3.connect(config.path_to_db) as db:
            cursor = db.cursor()
            cursor.execute("INSERT INTO bot_stats "
                       "(contacts_getted, media_getted) "
                       "VALUES (?, ?)",
                       [contacts_getted, media_getted])
            post_id = cursor.lastrowid
            assert post_id is not None
            db.commit()
            return [True, post_id]
    except IntegrityError:
        return False


def get_stats_data():
    with sqlite3.connect(config.path_to_db) as db:
        db.row_factory = dict_factory
        cur = db.cursor()
        sql = "SELECT * FROM bot_stats "
        data = cur.execute(sql).fetchone()
        if data is None:
            add_stats(0, 0)
            return cur.execute(sql).fetchone()
        return cur.execute(sql).fetchone()


def update_stats(setup_id, **kwargs):
    with sqlite3.connect(config.path_to_db) as db:
        sql = f"UPDATE bot_stats SET XXX WHERE setup_id = {setup_id}"
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()