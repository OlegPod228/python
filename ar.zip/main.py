import telebot
import config
import db
from telebot.util import async_dec
from buttons import main_markup, back_markup

bot = telebot.TeleBot(config.TOKEN)


@bot.message_handler(content_types=['text'])
def handler(message):
    if message.text == "Назад":
        cancel(message.chat.id)

    elif message.text == "/start":
        db.insert_data_to_db(message.from_user.id)
        bot.send_message(message.chat.id, "Главное меню", reply_markup=main_markup)

    elif message.text == "Добавить ссылку":
        bot.send_message(message.chat.id, "Введите ссылку", reply_markup=back_markup)
        bot.register_next_step_handler(message, add_url)

    elif message.text == "Удалить ссылку":
        if len(db.get_url(message.from_user.id)) != 0:
            bot.send_message(message.chat.id, f"Введите индекс ссылки:\n{db.get_url(message.from_user.id)}")
            bot.register_next_step_handler(message, del_url)
        else:
            bot.send_message(message.chat.id, "У вас нету ссылок")
    else:
        bot.send_message(message.from_user.id, "Не знаю что ответить, пропиши /start")
    parse()


@async_dec()
def del_url(message):
    try:
        try:
            db.del_url(message.from_user.id, int(message.text))
            bot.send_message(message.chat.id, "Ссылка удалена")
            parse()
        except:
            if len(db.get_url(message.from_user.id)) != 0:
                bot.send_message(message.chat.id, f"Введите индекс ссылки:\n{db.get_url(message.from_user.id)}")
                bot.register_next_step_handler(message, del_url)
            else:
                bot.send_message(message.chat.id, "У вас нету ссылок")
            parse()
    except:
        pass


@async_dec()
def add_url(message):
    try:
        if message.text == "Назад":
            cancel(message.chat.id)
        text = message.text.split(".")
        if text[1] == "kvd" or text[1] == "blocket":
            db.insert_url(message.from_user.id, message.text)
            bot.send_message(message.chat.id, "Ссылка добавлена", reply_markup=main_markup)
            parse()
        else:
            bot.send_message(message.chat.id, "Введите ссылку", reply_markup=back_markup)
            bot.register_next_step_handler(message, add_url)
            parse()
    except:
        pass


@async_dec()
def cancel(chat_id):
    try:
        bot.clear_step_handler_by_chat_id(chat_id)
        bot.send_message(chat_id, "Главное меню", reply_markup=main_markup)
        parse()
    except:
        pass

@async_dec()
def parse():
    while True:
        urls = db.select_all_urls()
        for data in urls:
            url_list = data[0].split("\n")
            url_list = url_list[1::]
            for url in url_list:
                try:
                    if config.get_type_site(url) == "kvd":
                        res = config.parse_kvd(data[1], url)
                        if res != None:
                            bot.send_message(url, res)
                    if config.get_type_site(url) == "blocket":
                        res = config.parse_blocket(data[1], url)
                        if res != None:
                            bot.send_message(data[1], res)
                except:
                    continue


parse()
bot.polling(none_stop=True)
