import sqlite3


def insert_data_to_db(user_id):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    lis = cursor.execute("SELECT `user_id` FROM `users`").fetchall()
    list_id = []
    for x in lis:
        list_id.append(x[0])
    if user_id not in list_id:
        cursor.execute("INSERT INTO `users` (`user_id`, `urls`, `last_parse_url`) VALUES (?,?,?)", (user_id, "", ""))
    connect.commit()


def insert_url(user_id, url):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    urls = cursor.execute("SELECT `urls` FROM `users` WHERE `user_id` = ?", (user_id,)).fetchone()[0].split("\n")
    urls.append(url)
    set_url = "\n".join(urls)
    cursor.execute("UPDATE `users` SET `urls` = ? WHERE `user_id` = ?", (set_url, user_id))
    connect.commit()


def select_all_urls():
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    data = cursor.execute("SELECT `urls`, `user_id` FROM `users` ").fetchall()
    ret_list = []
    for x in data:
        ret_list.append([x[0], x[1]])

    return ret_list


def select_url_of_id(user_id, url):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    data = cursor.execute("SELECT `last_parse_url` FROM `users` WHERE `user_id` = ?", (user_id,)).fetchone()[0].split(
        "\n")
    return url in data


def add_last_url_parse(user_id, url):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    urls = cursor.execute("SELECT `last_parse_url` FROM `users` WHERE `user_id` = ?", (user_id,)).fetchone()[0].split(
        "\n")
    urls.append(url)
    set_url = "\n".join(urls)
    cursor.execute("UPDATE `users` SET `last_parse_url` = ? WHERE `user_id` = ?", (set_url, user_id))
    connect.commit()


def del_url(user_id, id):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    data = cursor.execute("SELECT `urls` FROM `users` WHERE `user_id` = ?", (user_id,)).fetchone()[0].split("\n")
    del data[id]
    url = "\n".join(data)
    cursor.execute("UPDATE `users` SET `urls` = ? WHERE `user_id` = ?", (url, user_id))
    connect.commit()


def get_url(user_id):
    connect = sqlite3.connect("users.db")
    cursor = connect.cursor()
    data = cursor.execute("SELECT `urls` FROM `users` WHERE `user_id` = ?", (user_id,)).fetchone()[0].split("\n")

    text = ""
    for x, y in enumerate(data):
        if y != "":
            text += f"[{x}] {y}\n"
    return text
