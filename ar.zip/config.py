import requests
from bs4 import BeautifulSoup as bs
import random
import db

TOKEN = "2082958345:AAH1saHVOxChXRcKHy9KUedjocOFRvS4mzM"

user_agents = []

with open('user-agents.txt', 'r') as file:
    user_agents = file.read().split("\n")

def parse_blocket(user_id, url):
    try:
        user_agent = {'User-Agent':random.choice(user_agents)}
        req = requests.get(url, headers= user_agent)
        soup = bs(req.text, "html.parser")
        url = "https://www.blocket.se" + soup.find("div", class_="styled__Wrapper-sc-1kpvi4z-0 bOXZnc").find("a",class_="Link-sc-6wulv7-0 styled__StyledTitleLink-sc-1kpvi4z-10 gXaAv cTlWJ").get(
            "href")
        is_old_url = db.select_url_of_id(user_id, url)
        if is_old_url == False:
            print(url)
            db.add_last_url_parse(user_id, url)
            return url
        else:
            return None
    except Exception as e:
        return None


def parse_kvd(user_id, url):
    try:
        user_agent = {'User-Agent': random.choice(user_agents)}
        req = requests.get(url, headers=user_agent)
        soup = bs(req.text, "html.parser")
        url = "https://www.kvd.se" + soup.find("li", class_="AuctionsContent__VehicleCard-sc-164w9ip-8 gQKUJQ").find(
            "a").get("href")
        print(url)
        is_old_url = db.select_url_of_id(user_id, url)
        if is_old_url == False:
            print(url)
            db.add_last_url_parse(user_id, url)
            return url
        else:
            return None
    except Exception as e:
        print(e)
        return None

def get_type_site(url):
    url = url.split(".")
    if url[1] == "kvd":
        return "kvd"
    elif url[1] == "blocket":
        return "blocket"
    else:
        return ""
