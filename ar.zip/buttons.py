from telebot.types import *

main_markup = ReplyKeyboardMarkup(resize_keyboard=True)
add_url_btn = KeyboardButton("Добавить ссылку")
del_url_btn = KeyboardButton("Удалить ссылку")
main_markup.add(add_url_btn)
main_markup.add(del_url_btn)

back_markup = ReplyKeyboardMarkup(resize_keyboard=True).add(KeyboardButton("Назад"))